import React, { useState, useEffect } from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import {
  Grid,
  Card,
  CardContent,
  Typography,
  CardHeader,
} from "@material-ui/core/";
import "./performanceArea.scss";
import axiosClient from "../authentication/axios-client";

export default function PerformanceArea() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axiosClient.get("/Performance_Area/allAreas").then((response) => {
      setData(response.data);
      console.log(response.data);
    });
  }, []);
  return (
    <>
      <div
        className=""
        style={{
          borderBottomRightRadius: "50px",
          borderBottomLeftRadius: "50px",
          display: "flex",
          justifyContent:"right"
        }}
      >
        <p className="assessment-year" style={{ textAlign: "center" }}>
          Current Year of Assessment: 2023
        </p>
      </div>

      <p className="title-performance">Assessment Performance Areas</p>
      <div
        className="performance-container"
        style={{ height: "700px", marginLeft: 150 }}
      >
        <div className="row-widgets" style={{ marginLeft: 20 }}>
          <Box sx={{ mt: 2 }}>
            <Grid container spacing={2}>
              {data.map((performancearea, index) => (
                <Grid key={index} item xs={8} sm={"auto"} md={6}>
                  <Box
                    sx={{
                      borderRadius: "10px",
                      overflow: "hidden",
                      padding: "8px",
                      backgroundColor: "#FFFFFF",
                      boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                      height: "100%",
                      width: "70%",
                      fontSize: "14px",
                      cursor: "pointer",
                      "&:hover": {
                        backgroundColor: "#D6D6D3",
                      },
                    }}
                  >
                    <Typography variant="button" component="div">
                      Section :{performancearea.section}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {performancearea.performanceArea}
                    </Typography>
                    <br />
                    <br />
                    <Typography
                      variant="caption"
                      color="text.secondary"
                      style={{
                        display: "-webkit-box",
                        WebkitLineClamp: 3,
                        WebkitBoxOrient: "vertical",
                        overflow: "hidden",
                      }}
                    >
                      Percentage: 30%
                    </Typography>
                    <br />
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        </div>
      </div>
      <p className="title-performance">First Quarter Ends In : 35 days</p>
    </>
  );
}
