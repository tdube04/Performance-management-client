import * as React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
 export default function PreviousScorecards() {
  return (
    <Box
      sx={{
        display: "column",
        flexDirection: "column",
        alignItems: "center",
        gap: 2,
      }}
    >
      {/* Header Paper */}
      <Paper
        elevation={3}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          height: "50px",
          backgroundColor: "#f5f5f5",
          boxShadow: "0px 0px 6px -1px darkgreen",
        }}
      >
        <Typography variant="h5" sx={{ fontWeight: "bold" }}>
          Previous Scorecards
        </Typography>
      </Paper>
       {/* Body Paper */}
      <Paper
        elevation={3}
        sx={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-around",
          width: "100%",
          boxShadow: "0px 0px 6px -1px darkgreen",
        }}
      >
        <Typography variant="body2" sx={{ mt: 2 }}>
          Year
        </Typography>
        <Typography variant="body2" sx={{ mt: 2 }}>
          Quater
        </Typography>
        <Typography variant="body2" sx={{ mt: 2 }}>
          Score
        </Typography>
      </Paper>
    </Box>
  );
}
