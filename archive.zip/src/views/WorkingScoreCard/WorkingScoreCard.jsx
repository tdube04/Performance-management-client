import * as React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from '@mui/material/Typography';

export default function WorkingScoreCard () {
  return (
    <Box
      sx={{
        display: "flex",
        flexWrap: "wrap",
        "& > :not(style)": {
          m: 1,
          width: 500,
          height: 58,
        },
      }}
    >
      <Paper elevation={3} sx={{ display: "flex",}}>
        <Typography variant="body2" sx={{ mt: 2}}>
          Tafadzwa Dube
        </Typography>
        <Typography variant="body2" sx={{ mt: 2, ml:20 }}>
          5139
        </Typography>
        <Typography variant="body2" sx={{ mt: 2, ml:20 }}>
        ICT Graduate Trainee
        </Typography>
      </Paper>
      <Paper elevation={3}>Create Work Plan</Paper>
      <Paper elevation={3}>Create Work Plan</Paper>
      <Paper elevation={3}>Create Work Plan</Paper>
      <Paper elevation={3}>Create Work Plan</Paper>
    </Box>
  );
}
