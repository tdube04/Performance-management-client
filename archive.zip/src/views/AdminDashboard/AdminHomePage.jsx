import React, { useState, useEffect, useRef } from "react";

import Card from "@mui/material/Card";
import Widgets from "../../components/Widgets/Widgets";
import axiosClient from "../../authentication/axios-client";

export default function AdminHomePage() {
  const [data, setData] = useState([]);
  useEffect(() => {
    axiosClient.get("/Performance_Area/allAreas").then((response) => {
      setData(response.data);
      console.log(response.data);
    });
  }, []);

  return (
    <>
      <div className="widgets">
        <Widgets />
      </div>

      <div className="listContainer">
        <div className="listTitle">All Users</div>
      </div>
    </>
  );
}
