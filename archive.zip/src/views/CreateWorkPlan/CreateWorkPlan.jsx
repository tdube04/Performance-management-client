import React, { useState, useEffect, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Typography from "@material-ui/core/Typography";

import "./createWorkPlan.scss";

import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@material-ui/lab/TabContext";
import TabList from "@material-ui/lab/TabList";

import WorkPlanData from "../../components/WorkPlanData/workplandata";
import SummaryScores from "../../components/SummaryScores/SummaryScores";
import Signatures from "../../components/Signatures/Signatures";
import axiosClient from "../../authentication/axios-client";
import { useTheme, useMediaQuery } from "@material-ui/core";

import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";

import { borderRadius } from "@mui/system";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { styled } from "@mui/material/styles";

import clsx from "clsx";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionActions from "@material-ui/core/AccordionActions";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Chip from "@material-ui/core/Chip";
import Button from "@material-ui/core/Button";
import Divider from "@material-ui/core/Divider";
import AddIcon from "@mui/icons-material/Add";

import {
  useGmailTabsStyles,
  useGmailTabItemStyles,
} from "@mui-treasury/styles/tabs";

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
}));
export default function CreateWorkPlan() {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [performanceAreas, setPerformanceAreas] = React.useState([]);
  const [clicked, setClicked] = useState(false);
  const [programs, setPrograms] = useState([]);
  const [expanded, setExpanded] = React.useState(false);
  const [selectedOutcomes, setSelectedOutcomes] = useState([]);
  const [selectedPerfomance, setSelectedPerfomance] = useState([]);
  const [selectedPerfomanceIndex, setSelectedPerfomanceIndex] = useState("");
  const [selectedProgramIndex, setSelectedProgramIndex] = useState("");

  const performanceRef = useRef(null);
  const descriptionRef = useRef(null);
  const measurement_unitRef = useRef(null);
  const weightRef = useRef(null);
  const quarterly_targetRef = useRef(null);
  const annual_targetRef = useRef(null);
  const allowable_varianceRef = useRef(null);
  const previous_year_PerfomenaceRef = useRef(null);
  const current_targetRef = useRef(null);
  const responsible_DivisionRef = useRef(null);
  const actual_perfomanceRef = useRef(null);
  const appraisee_scoreRef = useRef(null);
  const indicatorRef = useRef(null);
  const measurementRef = useRef(null);

  const indicatorColors = ["#d93025", "#1a73e8", "#188038", "#e37400"];

  const tabItem3Styles = useGmailTabItemStyles({ color: indicatorColors[2] });

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const handleAccordionChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  React.useEffect(() => {
    axiosClient.get("/Performance_Area/allAreas").then((response) => {
      setPerformanceAreas(response.data);
      console.log(response.data);
    });
  }, []);

  const handlePerformanceClick = (area, index) => {
    console.log("Perfomance clicked", area);

    setSelectedPerfomance(area);
    setSelectedPerfomanceIndex(index);
    console.log("Perfomance", index);
  };

  const handleOutcomeItemClick = (program, index) => {
    console.log("Program clicked", program);
    console.log("Outcome ", program);
    console.log("Program index selected", index);

    setSelectedOutcomes(program);

    setSelectedProgramIndex(index);
  };

  const handleInputClick = () => {
    setMessage("");
  };
  return (
    <div className={classes.root}>
      <Box
        sx={{
          width: "100%",
          typography: "body1",
          fontWeight: "bold",
          borderRadius: 20,
          backgroundColor: "#e7e7e7",
        }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="simple tabs example"
          // textColor="secondary"
          // indicatorColor="secondary"
          variant="scrollable"
          scrollButtons
          allowScrollButtonsMobile
        >
          {performanceAreas.map((area, index) => (
            <Tab
              classes={tabItem3Styles}
              key={index}
              label={area.performanceArea}
              onClick={() => handlePerformanceClick(area, index)}
              sx={{
                fontSize: 8,
                color: "black",
                fontWeight: "bold",
                fontStyle: "sans-serif",
              }}
            />
          ))}
          <Tab label="Summary Scores" />
          <Tab label="Signatures" />
        </Tabs>
      </Box>

      {performanceAreas.map((area, index) => (
        <TabPanel key={index} value={value} index={index}>
          <h6>{area.performanceArea}</h6>
          {/* <p>{area.description}</p> */}

          <div className="">
            <Box
              sx={{
                mt: 2,
                display: "flex",
                flexWrap: "wrap",
                "& > :not(style)": {
                  m: 1,
                  width: 550,
                  height: 650,
                },
              }}
            >
              <Paper
                variant="outlined"
                sx={{
                  mt: 5,
                  ml: 20,
                  p: 2,
                  backgroundColor: "#FFFFFF",
                  boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                  borderTop: "10px solid #309366",
                  position: "relative",
                  elevation: 3,
                }}
              >
                <Box
                  sx={{
                    display: "grid",
                    flexWrap: "wrap",
                    "& > :not(style)": {
                      m: 1,
                      width: 450,
                      height: 45,
                      justifyContent: "center",
                    },
                  }}
                >
                  <div className={classes.root}>
                    <Typography
                      className={classes.heading}
                      style={{
                        display: "flex",
                        alignItems: "right",
                        justifyContent: "center",
                        marginBottom: "10px",
                        color: "black",
                      }}
                    >
                      Section : {area.section}
                    </Typography>
                    {area.programs &&
                      area.programs.map((program, programIndex) => (
                        <div
                          key={programIndex}
                          onClick={() =>
                            handleOutcomeItemClick(program, programIndex)
                          }
                        >
                          <Typography
                            className={classes.heading}
                            style={{
                              display: "flex",
                              alignItems: "right",
                              justifyContent: "center",
                              marginBottom: "10px",
                              color: "black",
                            }}
                          >
                            {program.name}
                          </Typography>

                          <Accordion
                            expanded={expanded === "panel1"}
                            onChange={handleAccordionChange("panel1")}
                          >
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel1bh-content"
                              id="panel1bh-header"
                            >
                              <Typography
                                sx={{
                                  width: "33%",
                                  flexShrink: 0,
                                  justifyContent: "center",
                                  marginTop: "10px",
                                }}
                              >
                                Outcome Indicators
                              </Typography>
                            </AccordionSummary>
                            {program.indicators.map(
                              (indicator, indicatorIndex) => (
                                <AccordionDetails key={indicatorIndex}>
                                  <Typography>
                                    <ul>
                                      <li>{indicator.weight}</li>
                                    </ul>
                                  </Typography>
                                </AccordionDetails>
                              )
                            )}
                          </Accordion>
                        </div>
                      ))}
                  </div>
                </Box>
              </Paper>

              {/* <WorkPlanData
                percent={area.weight}
                performanceAreatitle={area.performanceArea}
                section={area.section}
                programs={area.programs}
                outcome={selectedOutcomes.name}
                outcomes={selectedOutcomes}
                progIndex={selectedProgramIndex}
                index={area.id}
                performanceArea={selectedPerfomance}
              /> */}

              <Box display="block" style={{ height: "700px" }}>
                <div className="full-description">
                  <Box
                    sx={{
                      marginLeft: 20,
                      display: "flex",
                      flexWrap: "wrap",
                      "& > :not(style)": {
                        m: 1,
                        width: 428,
                        height: 700,
                      },
                    }}
                  >
                    <Paper
                      variant="outlined"
                      sx={{
                        p: 2,
                        backgroundColor: "#FFFFFF",
                        boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                        borderTop: "20px solid #309366",
                        position: "relative",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Typography
                          className={classes.heading}
                          style={{
                            display: "flex",
                            alignItems: "right",
                            justifyContent: "center",
                            marginBottom: "10px",
                            color: "black",
                          }}
                        >
                          {/* {props.section} - {props.outcome} */}
                        </Typography>
                      </div>
                      <br />
                      <form
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "flex",
                        }}
                      >
                        <div style={{ display: "flex" }}>
                          <label>Outcome Indicator: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={indicatorRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex" }}>
                          <label>Measurement Unit: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={measurementRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex" }}>
                          <label>Weight: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={weightRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Perfomance of 2022: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={previous_year_PerfomenaceRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Annual target for 2023: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={annual_targetRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Target for Q4 2022: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={current_targetRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Responsible Division: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={responsible_DivisionRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Actual Perfomance: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={actual_perfomanceRef}
                            onClick={handleInputClick}
                          />
                        </div>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Allowable variance: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={actual_perfomanceRef}
                            onClick={handleInputClick}
                          />
                        </div>

                        <div style={{ display: "flex", flexDirection: "row" }}>
                          <label>Apraisee Score: </label>

                          <input
                            type="text"
                            className="input-pillar"
                            ref={appraisee_scoreRef}
                            onClick={handleInputClick}
                          />
                        </div>

                        <div className="btn-outcome-program">
                          <button
                            className="btn-outcome"
                            style={{ borderRadius: "25px" }}
                          >
                            Add
                          </button>
                        </div>
                      </form>
                    </Paper>
                  </Box>
                </div>
              </Box>
            </Box>
          </div>
        </TabPanel>
      ))}
    </div>
  );
}
