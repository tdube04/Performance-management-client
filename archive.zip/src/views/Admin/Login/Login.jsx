import { Link } from "react-router-dom";
import axiosClient from "../../../authentication/axios-client";
import { createRef, useRef } from "react";
import { useStateContext } from "../../../context/ContextProvider.jsx";
import { useState, useEffect } from "react";
import "./login.scss";
import "animate.css/animate.min.css";
import jwt_decode from "jwt-decode";
import CircularProgress from "@mui/material/CircularProgress";
import Swal from "sweetalert2";

export default function Login() {
  const usernameRef = useRef();
  const passwordRef = useRef();
  const { setUser, setToken, setUserType } = useStateContext();
  const [message, setMessage] = useState(null);
  const [userData, setUserData] = useState(null);
  const [decodedToken, setDecodedToken] = useState(null);
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const onSubmit = (ev) => {
    ev.preventDefault();

    const username = usernameRef.current.value;
    const password = passwordRef.current.value;

    if (!username || !password) {
      setMessage("Please fill in all required fields");
      return;
    }

    const payload = {
      username: usernameRef.current.value,
      password: passwordRef.current.value,
    };
    setIsLoading(true);
    axiosClient
      .post("/login", payload)
      .then(({ data }) => {
        setToken(data.jwtToken);
        console.log(data.jwtToken);
        const decodedToken = jwt_decode(data.jwtToken);

        if (decodedToken.ADMIN) {
          setUserType("ADMIN");
          console.log("ADMIN");
        } else if (decodedToken.USER) {
          setUserType("USER");
          console.log("USER");
        } else {
          setUserType("UNKNOWN");
          console.log("UNKNOWN");
        }
        Swal.fire({
          title: "Success!",
          text: data.message,
          icon: "success",
          timer: 2000,
        });
      })
      .catch((err) => {
        const response = err.response;
        if (response && response.status === 422) {
          setMessage(response.data.message);
        }
      })
      .finally(() => {
        setIsLoading(false);
      });
  };
  const handleInputClick = () => {
    setMessage("");
  };

  return (
    <div className="login-signup-form animated fadeInDown">
      <div className="form">
        <form onSubmit={onSubmit}>
          <h1 className="title">Login into your account</h1>
          {message && (
            <div className="alert">
              <p>{message}</p>
            </div>
          )}
          <label>Username: </label>
          <input
            className="input1"
            ref={usernameRef}
            type="text"
            placeholder="Username"
            variant="outlined"
            onClick={handleInputClick}
          />{" "}
          <br />
          <br />
          <label>Password: </label>
          <input
            className="input2"
            ref={passwordRef}
            type="password"
            placeholder="Password"
            onClick={handleInputClick}
          />
          <br />
          <br />
          <div className="">
            <button className="btn-login">{isLoading ? (
                <div style={{ margin: "auto" }}>
                  <CircularProgress color="success" />{" "}
                </div>
              ) : (
                "Submit"
              )}</button>
          </div>
       
          {userData && (
            <div>
              <p>Welcome, {userData.sub}!</p>
              <ul>
                {userData.ADMIN.map((permission, index) => (
                  <li key={index}>{permission}</li>
                ))}
              </ul>
            </div>
          )}
          {/* <p className="message">
            Not registered? <Link to="/signup">Create an account</Link>
          </p> */}
          {message && (
            <div className="alert alert-danger">
              <p>{message}</p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
