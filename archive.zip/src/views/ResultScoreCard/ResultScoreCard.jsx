import React from 'react'

export const ResultScoreCard = () => {
  return (
    <div>ResultScoreCard</div>
  )
}
