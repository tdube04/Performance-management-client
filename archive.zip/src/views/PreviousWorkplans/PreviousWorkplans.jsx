import * as React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Typography from "@mui/material/Typography";
import TablePagination from "@mui/material/TablePagination";
 
export default function PreviousWorkplans() {
  const [workPlans, setWorkPlans] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(6);

  React.useEffect(() => {
    async function fetchWorkPlans() {
      const response = await fetch("your_api_endpoint");
      const data = await response.json();
      setWorkPlans(data);
    }
    fetchWorkPlans();
  }, []);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const emptyRows =
    rowsPerPage - Math.min(rowsPerPage, workPlans.length - page * rowsPerPage);

  return (
    <Box
      sx={{
        display: "column",
        flexDirection: "column",
        alignItems: "center",
        gap: 2,
      }}
    >
      {/* Header */}
      <Paper
        elevation={3}
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          height: "50px",
          backgroundColor: "#f5f5f5",
          boxShadow: "0px 0px 6px -1px darkgreen",
        }}
      >
        <Typography variant="h5" sx={{ fontWeight: "bold" }}>
          Previous Work Plans
        </Typography>
      </Paper>
      {/* Table */}
      <TableContainer
        component={Paper}
        sx={{ boxShadow: "0px 0px 6px -1px darkgreen" }}
      >
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Year</TableCell>
              <TableCell>Quarter</TableCell>
              <TableCell>Workplan</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {workPlans
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((workPlan) => (
                <TableRow key={workPlan.id}>
                  <TableCell>{workPlan.year}</TableCell>
                  <TableCell>{workPlan.quarter}</TableCell>
                  <TableCell>{workPlan.workplan}</TableCell>
                </TableRow>
              ))}
            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={3} />
              </TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[6, 12, 18]}
          component="div"
          count={workPlans.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    </Box>
  );
}