import { createBrowserRouter, Navigate } from "react-router-dom";
import Login from "./views/Admin/Login/Login";
import NotFound from "./views/NotFound/NotFound";
import Signup from "./views/SignupPage/Signup";
import AppraiseeDashboard from "./components/AppraiseeDashboard/AppraiseeDashboard.jsx";
import CreateWorkPlan from "./views/CreateWorkPlan/CreateWorkPlan";
import PerformanceArea from "./Widgets/PerformanceArea";
import PendingApproval from "./views/PendingApproval/PendingApproval";
import Rejected from "./views/Rejected/Rejected";
import Approved from "./views/Approved/Approved";
import UnderReview from "./views/UnderReview/UnderReview";
import UnderEvaluation from "./views/UnderEvaluation/UnderEvaluation";
import Completed from "./views/Completed/Completed";
import PreviousScorecards from "./views/PreviousScorecards/PreviousScorecards";
import PreviousWorkplans from "./views/PreviousWorkplans/PreviousWorkplans";
import CurrentScoreCard from "./views/WorkingScoreCard/WorkingScoreCard";
import WorkingScoreCard from "./views/WorkingScoreCard/WorkingScoreCard";
import { MyDashboard } from "./MyDashboard/MyDashboard";
import { ResultScoreCard } from "./views/ResultScoreCard/ResultScoreCard";
import AllIrbms from "./views/AllIrbms/AllIrbms";
import GuestLayout from "./components/GuestLayout";
import AdminLayout from "./components/AdminLayout/AdminLayout";
import AdminHomePage from "./views/AdminDashboard/AdminHomePage";
import AddPillars from "./components/Pillars/AddPillars/AddPillars";
import ViewPillars from "./components/Pillars/ViewPillars/ViewPillars";
import SelectCurrentYear from "./components/Pillars/SelectCurrentYear/SelectCurrentYear";
import AddDivision from "./components/Divisions/AddDivision/AddDivision";
import ViewDivisions from "./components/Divisions/ViewDivisions/ViewDivisions";
import AddOutcomes from "./components/Outcomes/AddOutcomes/AddOutcomes";
import AddForCurrentYear from "./components/Outcomes/AddForCurrentYear/AddForCurrentYear";

const router = createBrowserRouter([
  {
    path: "/",
    element: <AppraiseeDashboard />,
    children: [
      {
        path: "/",
        element: <PerformanceArea />,
      },

      {
        path: "/dashboard",
        element: <AppraiseeDashboard />,
        
      },
      {
        path: "/completed",
        element: <Completed />,
      },

      {
        path: "/createWorkPlan",
        element: <CreateWorkPlan />,
      },

      {
        path: "/pendingApproval",
        element: <PendingApproval />,
      },
      {
        path: "/allirbms",
        element: <AllIrbms />,
      },

      {
        path: "/rejected",
        element: <Rejected />,
      },

      {
        path: "/approved",
        element: <Approved />,
      },

      {
        path: "/underreview",
        element: <UnderReview />,
      },

      {
        path: "/underevaluation",
        element: <UnderEvaluation />,
      },

      {
        path: "/completed",
        element: <Completed />,
      },
      {
        path: "/previousscorecards",
        element: <PreviousScorecards />,
      },
      {
        path: "/previousworkplans",
        element: <PreviousWorkplans />,
      },
      {
        path: "/workingscorecard",
        element: <WorkingScoreCard />,
      },
      {
        path: "/resultscorecard",
        element: <ResultScoreCard />,
      },
    ],
  },
  {
    path: "/",
    element: <GuestLayout />,
    children: [
      {
        path: "/login",
        element: <Login />,
      },
      {
        path: "/signup",
        element: <Signup />,
      },
    ],
  },
  {
    path: "/admin",
    element: <AdminLayout />,
    children: [
      {
        path: "/admin/dashboard",
        element: <AdminHomePage />,
      },
      {
        path: "/admin/performanceAreas",
        element: <PerformanceArea />,
      },
      {
        path: "/admin/addPillars",
        element: <AddPillars />,
      },
      {
        path: "/admin/viewPillars",
        element: <ViewPillars />,
      },
      {
        path: "/admin/currentYearPillars",
        element: <SelectCurrentYear />,
      },
      {
        path: "/admin/addDivision",
        element: <AddDivision />,
      },
      {
        path: "/admin/viewDivisions",
        element: <ViewDivisions />,
      },
      {
        path: "/admin/addOutcomes",
        element: <AddOutcomes />,
      },
      {
        path: "/admin/addOutcomes-information",
        element: <AddForCurrentYear />,
      },
    
    ],
  },

  {
    path: "*",
    element: <NotFound />,
  },
]);

export default router;
