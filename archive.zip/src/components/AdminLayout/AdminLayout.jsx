import { Link, Navigate, Outlet } from "react-router-dom";
import { useStateContext } from "../../context/ContextProvider";

import { useEffect } from "react";
import SideBar from "../SideBar/SideBar";
import "./home.scss";
import NavBar from "../NavBar/NavBar";

import AdminSideBar from "../SideBar/AdminSideBar";

export default function AdminLayout() {
  const { token, setToken } = useStateContext();

  if (!token) {
    return <Navigate to="/login" />;
  }

  const onLogout = (ev) => {
    ev.preventDefault();
  };

  return (
    <div id="defaultLayout" className="home">
      <AdminSideBar />

      <div id="homeContainer" className="homeContainer">
        <NavBar />

        <div className="recents">
          <main>
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}
