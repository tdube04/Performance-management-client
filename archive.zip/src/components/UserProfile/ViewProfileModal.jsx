import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import Typography from "@mui/material/Typography";
import "bootstrap/dist/css/bootstrap.min.css";
import { AttachFile } from "@mui/icons-material";
// import AttachFileIcon from '@mui/icons-material/AttachFile';
import axios from "axios";
import axiosClient from "../../authentication/axios-client";

function ViewProfileModal() {
  const [show, setShow] = useState(false);

  const [ecNumber,setEcNumber] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [division, setDivision] = useState("");
  const [position, setPosition] = useState("");
  const [section, setSection] = useState("");
  const [email, setEmail] = useState("");
  const [grade, setGrade] = useState("");
  const [name, setName] = useState("");


  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSaveProfile = (event) => {
    event.preventDefault();

    const formData = {
      ec_number: ecNumber,
      name: name,
      email: email,
      grade: grade,
      divisionName: division,
      positionName:position,
      sectionName:section
    };

    axiosClient
      .post("/saveUser", formData)
      .then((response) => {
        if (response.status === 200) {
         console.log(response.data);
         swal({
          text: "Profile Saved Successfully",
          icon: "success",
          button: "OK!",
        })
        } else {
          // Error!
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <Typography onClick={handleShow}>Profile</Typography>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>My Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Form.Label column="sm" lg={2}>
              EC Number
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                value={ecNumber}
                onChange={(e) => setEcNumber(e.target.value)}
                defaultValue="EC Number"
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
             Email
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
             Grade
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
              Name
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
              Division
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={division}
                onChange={(e) => setDivision(e.target.value)}
              />
            </Col>
          </Row>
          <br/>
          <Row>
            <Form.Label column="sm" lg={2}>
              Position
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
              Section
            </Form.Label>
            <Col>
              <Form.Control
                size="sm"
                type="text"
                defaultValue="text"
                value={section}
                onChange={(e) => setSection(e.target.value)}
              />
            </Col>
          </Row>
          <br />
          <Row>
            <Form.Label column="sm" lg={2}>
             Attach Signature
            </Form.Label>
            <Col>
              <AttachFile/>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSaveProfile}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ViewProfileModal;
