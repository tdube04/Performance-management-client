import * as React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from '@mui/material/Typography';
import { Grid } from "@mui/material";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { FormControl, FormLabel } from '@mui/material';
import { styled } from '@mui/material/styles';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Dropdown from "../Dropdown/Dropdown";



export default function SummaryScores() {
    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>

            <Typography variant="h5" align="center" color="green">IRBM Performance Contract Evaluation</Typography>

            <FormControl><Dropdown/></FormControl>

            <Box sx={{ display: "flex", flexDirection: "row", flexWrap: "wrap", width: "100%" }}>
                <Box sx={{ width: "20%" }}>
                    <Grid container spacing={2} sx={{ display: "flex", flexDirection: "column", width: "50%", '& > *': { marginBottom: 7 } }}>
                        <Grid item xs={6} >
                            <Paper elevation={0}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>SECTION</Typography>
                            </Paper>

                        </Grid>
                        <Grid item xs={6} >
                            <Paper sx={{ backgroundColor: 'rgba(0,255, 0, 0.3)', clipPath: "polygon(0% 0%, 100% 50%, 0% 100%)" }}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>A1</Typography>
                            </Paper>

                        </Grid>
                        <Grid item xs={6}>
                            <Paper sx={{ bgcolor: 'greenyellow', clipPath: "polygon(0% 0%, 100% 50%, 0% 100%" }}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>A2</Typography>
                            </Paper>
                        </Grid>

                        <Grid item xs={6}>
                            <Paper sx={{ bgcolor: 'gray', clipPath: "polygon(0% 0%, 100% 50%, 0% 100%" }}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>B</Typography>
                            </Paper>
                        </Grid>

                        <Grid item xs={6}>
                            <Paper sx={{ backgroundColor: 'rgba(255, 0, 0, 0.3)', clipPath: "polygon(0% 0%, 100% 50%, 0% 100%" }}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>C</Typography>
                            </Paper>
                        </Grid>

                        <Grid item xs={6}>
                            <Paper sx={{ bgcolor: 'rgba(0, 0, 255, 0.3)', clipPath: "polygon(0% 0%, 100% 50%, 0% 100%" }}>
                                <Typography variant="h6" style={{ textAlign: 'center', fontWeight: "bold" }}>D</Typography>
                            </Paper>
                        </Grid>
                    </Grid>
                </Box>

                <Box sx={{ width: "50%" }}>
                    <TableContainer component={Paper} style={{ height: '550px' }}>
                        <Table>
                            <TableHead>
                                <TableRow style={{ height: '50px', backgroundColor: '#e6e6e6', border: '1px solid black' }}>
                                    <TableCell style={{ border: '1px solid black' }}>Description</TableCell>
                                    <TableCell style={{ border: '1px solid black' }}>Weight</TableCell>
                                    <TableCell style={{ border: '1px solid black' }}>Weighted Score</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow style={{ height: '100px', backgroundColor: '#f2f2f2', border: '1px solid black' }}>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                </TableRow>
                                <TableRow style={{ height: '100px', backgroundColor: '#f2f2f2',border: '1px solid black'}}>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                </TableRow>
                                <TableRow style={{ height: '100px', backgroundColor: '#f2f2f2', border: '1px solid black' }}>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                </TableRow>
                                <TableRow style={{ height: '100px', backgroundColor: '#f2f2f2', border: '1px solid black' }}>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                </TableRow>
                                <TableRow style={{ height: '100px', backgroundColor: '#f2f2f2', border: '1px solid black' }}>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                    <TableCell style={{ border: '1px solid black' }}></TableCell>
                                </TableRow>

                            </TableBody>
                        </Table>
                    </TableContainer>
                </Box>



                <Box sx={{ width: "30%" }}>
                    <FormControl>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <div style={{ display: 'flex', marginBottom:'20px'}}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px' }}>Name of Appraisee</FormLabel>
                            <TextField style={{ display: 'inline-flex',backgroundColor: '#f2f2f2'}}></TextField>
                        </div>
                        <div style={{ display: 'flex', marginBottom:'20px'}}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px' }}>Signature</FormLabel>
                            <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
                        </div>
                        <div style={{ display: 'flex', marginBottom:'20px'}}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px' }}>Date</FormLabel>
                            <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
                        </div>
                        <div style={{ display: 'flex', marginBottom:'20px' }}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px' }}>Name of Appraiser</FormLabel>
                            <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
                        </div>
                        <div style={{ display: 'flex', marginBottom:'20px' }}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px' }}>Signature</FormLabel>
                            <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
                        </div>
                        <div style={{ display: 'flex', marginBottom:'20px' }}>
                            <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", marginLeft: '20px'}}>Date</FormLabel>
                            <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'flex-end'}}>
                        <Button style={{fontWeight: "bold",backgroundColor: "green", color:'white', width: "225px"}}>Submit</Button>
                        </div>
                        </div>

        
                    </FormControl>
                </Box>
            </Box>


            <FormControl>
    <div style={{ display: 'flex', justifyContent: 'left', marginTop:'20px', marginBottom:'20px'}}>
    <FormLabel style={{ display: 'inline-flex', fontWeight: "bold", color:'black'}}>Total Weighted Score (after adjustment for Not Rated):</FormLabel>
    <TextField style={{ display: 'inline-flex', backgroundColor: '#f2f2f2'}}></TextField>
    </div>
    </FormControl>

        </div>

    );
}
