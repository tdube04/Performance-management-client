import React, { useState, useEffect, useRef } from "react";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { borderRadius } from "@mui/system";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { styled } from "@mui/material/styles";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionActions from "@material-ui/core/AccordionActions";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Chip from "@material-ui/core/Chip";
import Button from "@material-ui/core/Button";
import Divider from "@material-ui/core/Divider";
import axiosClient from "../../../authentication/axios-client";
import AddIcon from "@mui/icons-material/Add";
import "animate.css/animate.min.css";
import "./addOutcomes.scss";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import { UpdateDisabledRounded } from "@mui/icons-material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(10),
    color: theme.palette.text.secondary,
  },
  icon: {
    verticalAlign: "bottom",
    height: 20,
    width: 20,
  },
  details: {
    alignItems: "center",
  },
  column: {
    flexBasis: "33.33%",
  },
  helper: {
    borderLeft: `2px solid ${theme.palette.divider}`,
    padding: theme.spacing(1, 2),
  },
  link: {
    color: theme.palette.primary.main,
    textDecoration: "none",
    "&:hover": {
      textDecoration: "underline",
    },
  },
}));

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
  fontSize: 12,
}));

export default function AddOutcomes() {
  const classes = useStyles();

  const [data, setData] = useState([]);

  const [selectedPerfomance, setSelectedPerfomance] = useState([]);

  const [selectedProgramIndex, setSelectedProgramIndex] = useState(0);

  const [selectedPerfomanceIndex, setSelectedPerfomanceIndex] = useState(0);

  const [selectedOutcomes, setSelectedOutcomes] = useState([]);

  const outcomeRef = useRef(null);
  const sectionRef = useRef(null);
  const percentRef = useRef(null);
  const performanceRef = useRef(null);
  const descriptionRef = useRef(null);
  const measurement_unitRef = useRef(null);
  const weightRef = useRef(null);
  const quarterly_targetRef = useRef(null);
  const annual_targetRef = useRef(null);
  const allowable_varianceRef = useRef(null);
  const previous_year_PerfomenaceRef = useRef(null);

  const [errors, setErrors] = useState([]);
  const [message, setMessage] = useState(null);
  const [showAddOutcome, setShowAddOutcome] = useState(false);
  const [showOutcomeForm, setShowOutcomeForm] = useState(false);
  const [showAddPerformance, setShowAddPerformance] = useState(false);

  useEffect(() => {
    axiosClient.get("/Performance_Area/allAreas").then((response) => {
      setData(response.data);
      console.log(response.data);
    });
  }, []);

  const handlePerformanceClick = (area, index) => {
    console.log("Perfomance clicked", area);

    setSelectedPerfomance(area);
    setSelectedPerfomanceIndex(index);
    console.log("Perfomance", index);
  };
  const handleOutcomeClick = (outcome) => {
    console.log("Outcome clicked", outcome);

    setSelectedOutcomes(outcome);
    setShowAddOutcome(true);
    setShowOutcomeForm(false);
    setShowAddPerformance(false);
  };

  const handleAddOutcomeClick = () => {
    setShowAddOutcome(true);
    setShowOutcomeForm(false);
    setShowAddPerformance(false);
  };

  const handleAddPerformanceClick = () => {
    setShowAddPerformance(true);
    setShowOutcomeForm(false);
    setShowAddOutcome(false);
  };

  const handleOutcomeItemClick = (program, index) => {
    console.log("Outcome clicked", program);
    console.log("Outcome ", program);
    console.log("Program index selected", index);

    setSelectedOutcomes(program);
    handleOutcomeClick(program);
    setShowAddOutcome(false);
    setShowAddPerformance(false);
    setShowOutcomeForm(true);
    setSelectedProgramIndex(index);
  };

  // const handleProgramSelect = (event) => {
  //   const index = event.target.value;
  //   console.log("Program selected", index);
  //   setSelectedProgramIndex(index);
  // };

  const handleSubmitOutcome = (e) => {
    e.preventDefault();

    let errors = [];

    if (!outcomeRef.current.value) {
      errors.push("Outcome is required.");
      setMessage("Please fill in all required fields");
    }

    if (errors.length > 0) {
      setErrors(errors);
      return;
    }

    const updatedPerformanceArea = { ...selectedPerfomance };

    const newProgram = {
      name: outcomeRef.current.value,
    };

    // updatedPerformanceArea.programs.push(newProgram);

    if (updatedPerformanceArea.programs) {
      updatedPerformanceArea.programs.push(newProgram);
    } else {
      updatedPerformanceArea.programs = [newProgram];
    }

    axiosClient
      .post(
        `Performance_Area/update/${selectedPerfomance.id}`,
        updatedPerformanceArea
      )
      .then((res) => {
        console.log(res);
        swal({
          text: "Outcome Saved Successfully",
          icon: "success",
          button: "OK!",
        }).then(() => {
          window.location.replace("/admin/addOutcomes");
        });
        outcomeRef.current.value = "";
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleSubmitPerfomance = (e) => {
    e.preventDefault();

    let errors = [];

    if (!performanceRef.current.value) {
      errors.push("Perfomance Area is required.");
      setMessage("Please fill in all required fields");
    }

    if (errors.length > 0) {
      setErrors(errors);
      return;
    }

    const updatedPerformanceArea = { ...data };

    const newPerformance = {
      performanceArea: performanceRef.current.value,
      wieght: percentRef.current.value,
      section: sectionRef.current.value,
    };

    Object.assign(updatedPerformanceArea, newPerformance);

    axiosClient
      .post("Performance_Area/save/", updatedPerformanceArea)
      .then((res) => {
        console.log(res);
        swal({
          text: "Performance Area Saved Successfully",
          icon: "success",
          button: "OK!",
        }).then(() => {
          window.location.replace("/admin/addOutcomes");
        });
        performanceRef.current.value = "";
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleSubmitIndicators = (e) => {
    e.preventDefault();

    const updatedPerformanceArea = { ...selectedPerfomance };

    const newProgramData = {
      description: selectedOutcomes.name,
      measurement_unit: measurement_unitRef.current.value,
      weight: weightRef.current.value,
      quarterly_target: quarterly_targetRef.current.value,
      annual_target: annual_targetRef.current.value,
      allowable_variance: allowable_varianceRef.current.value,
      previous_year_Perfomenace: previous_year_PerfomenaceRef.current.value,
    };
    if (
      updatedPerformanceArea.programs &&
      Array.isArray(updatedPerformanceArea.programs)
    ) {
      const selectedProgram =
        updatedPerformanceArea.programs[selectedProgramIndex];
      if (!selectedProgram.indicators) {
        selectedProgram.indicators = [];
      }
      selectedProgram.indicators.push(newProgramData);
    } else {
      throw new Error("The programs array is null or not an array");
    }

    axiosClient
      .post(
        `Performance_Area/update/${selectedPerfomance.id}`,
        updatedPerformanceArea
      )
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleInputClick = () => {
    setMessage("");
  };

  return (
    <Box display="flex" style={{ height: "700px" }}>
      <div className="" style={{ overflow: "scroll" }}>
        <Box
          sx={{
            mt: 2,
            display: "flex",
            flexWrap: "wrap",
            "& > :not(style)": {
              m: 1,
              width: 500,
              height: 650,
            },
          }}
        >
          <Paper
            variant="outlined"
            sx={{
              mt: 5,
              ml: 20,
              p: 2,
              backgroundColor: "#FFFFFF",
              boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
              borderTop: "10px solid #FFFF80",
              position: "relative",
              elevation: 3,
            }}
          >
            <Box
              sx={{
                display: "grid",
                flexWrap: "wrap",
                "& > :not(style)": {
                  m: 1,
                  width: 450,
                  height: 45,
                },
              }}
            >
              <div className={classes.root}>
                <Typography
                  className={classes.heading}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: "10px",
                    color: "black",
                  }}
                >
                  Performance Areas
                  <AddCircleOutlineIcon onClick={handleAddPerformanceClick} />
                </Typography>

                {data &&
                  data.map((area, index) => (
                    <Accordion
                      key={index}
                      onClick={() => handlePerformanceClick(area, index)}
                    >
                      <AccordionSummary
                        style={{ backgroundColor: "#e2e2e2" }}
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1c-content"
                        id="panel1c-header"
                      >
                        <div className={classes.column}>
                          <Typography className={classes.heading}></Typography>
                        </div>
                        <div>
                          <Typography
                            className={classes.secondaryHeading}
                            sx={{ fontSize: 12, color: "black" }}
                          >
                            {area.section} {area.performanceArea}
                          </Typography>
                        </div>
                      </AccordionSummary>
                      <div>
                        Programs{" "}
                        <Button
                          size="small"
                          color="primary"
                          className="btn-addOutcome"
                          onClick={handleAddOutcomeClick}
                        >
                          <AddCircleOutlineIcon />
                        </Button>
                      </div>
                      <AccordionDetails className={classes.details}>
                        <div className={classes.column} />
                        <Box sx={{ width: "100%" }}>
                          <Grid
                            container
                            rowSpacing={2}
                            columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                          >
                            <Grid item xs={8}>
                              {area.programs &&
                                area.programs.map((program, index) => (
                                  <Item
                                    sx={{ marginBottom: 2 }}
                                    key={index}
                                    onClick={() =>
                                      handleOutcomeItemClick(program, index)
                                    }
                                  >
                                    {program.name}
                                    <MoreVertIcon />
                                  </Item>
                                ))}
                            </Grid>
                            <br />
                          </Grid>
                        </Box>
                      </AccordionDetails>
                      <Divider />
                      <AccordionActions></AccordionActions>
                    </Accordion>
                  ))}
              </div>
            </Box>
          </Paper>
        </Box>
      </div>
      {showAddOutcome && (
        <div className="add-outcome">
          <Box
            sx={{
              mt: 2,
              marginLeft: 20,
              display: "flex",
              flexWrap: "wrap",
              "& > :not(style)": {
                m: 1,
                width: 428,
                height: 350,
              },
            }}
          >
            <Paper
              variant="outlined"
              sx={{
                mt: 2,
                p: 2,
                backgroundColor: "#FFFFFF",
                boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                borderTop: "20px solid #309366",
                position: "relative",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Typography variant="body2" sx={{ mt: 6 }}>
                  {selectedPerfomance.section} -{" "}
                  {selectedPerfomance.performanceArea}
                </Typography>
              </div>
              <br />
              <form onSubmit={handleSubmitOutcome}>
                {message && (
                  <div className="alert alert-danger animate__animated animate__bounceIn">
                    <p>{message}</p>
                  </div>
                )}
                <label>Enter Outcome</label>
                <div>
                  <input
                    type="text"
                    className="input-pillar animate__animated animate__bounceIn"
                    ref={outcomeRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div className="btn-outcome-program">
                  <button
                    className="btn-outcome animate__animated animate__pulse"
                    style={{ borderRadius: "25px" }}
                  >
                    Add
                  </button>
                </div>
              </form>
            </Paper>
          </Box>
        </div>
      )}
      {showOutcomeForm && (
        <div className="outcome-form">
          <Box
            sx={{
              mt: 2,
              marginLeft: 20,
              display: "flex",
              flexWrap: "wrap",
              "& > :not(style)": {
                m: 1,
                width: 428,
                height: 700,
              },
            }}
          >
            <Paper
              variant="outlined"
              sx={{
                mt: 2,
                p: 2,
                backgroundColor: "#FFFFFF",
                boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                borderTop: "20px solid #309366",
                position: "relative",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Typography variant="body2" sx={{ mt: 6 }}>
                  {selectedPerfomance.section} - {selectedOutcomes.name}
                </Typography>
              </div>
              <br />
              <form
                onSubmit={handleSubmitIndicators}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-end",
                }}
              >
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}> Measurement Unit</label>

                  <input
                    type="text"
                    className="input-pillar"
                    ref={measurement_unitRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Weight</label>

                  <input
                    type="text"
                    className="input-pillar"
                    onClick={handleInputClick}
                    ref={weightRef}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Performance 2022 </label>

                  <input
                    type="text"
                    className="input-pillar"
                    ref={previous_year_PerfomenaceRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Quarterly Target </label>

                  <input
                    type="text"
                    className="input-pillar"
                    ref={quarterly_targetRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Annual Target </label>

                  <input
                    type="text"
                    className="input-pillar"
                    ref={annual_targetRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>
                    Allowable Variance{" "}
                  </label>

                  <input
                    type="text"
                    className="input-pillar"
                    ref={allowable_varianceRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>
                    Responsible Division{" "}
                  </label>

                  <input
                    type="text"
                    className="input-pillar"
                    onClick={handleInputClick}
                  />
                </div>

                <div className="btn-outcome-program">
                  <button
                    className="btn-outcome"
                    style={{ borderRadius: "25px" }}
                  >
                    Add
                  </button>
                </div>
              </form>
            </Paper>
          </Box>
        </div>
      )}
      {showAddPerformance && (
        <div className="add-outcome">
          <Box
            sx={{
              mt: 2,
              marginLeft: 20,
              display: "flex",
              flexWrap: "wrap",
              "& > :not(style)": {
                m: 1,
                width: 428,
                height: 400,
              },
            }}
          >
            <Paper
              variant="outlined"
              sx={{
                mt: 2,
                p: 2,
                backgroundColor: "#FFFFFF",
                boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
                borderTop: "20px solid #309366",
                position: "relative",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Typography variant="body2" sx={{ mt: 6 }}>
                  Add a Performance Area
                </Typography>
              </div>
              <br />
              <form onSubmit={handleSubmitPerfomance}>
                {message && (
                  <div className="alert alert-danger animate__animated animate__bounceIn">
                    <p>{message}</p>
                  </div>
                )}

                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>
                    Enter Performance Area
                  </label>

                  <input
                    type="text"
                    className="input-pillar animate__animated animate__bounceIn"
                    ref={performanceRef}
                    onClick={handleInputClick}
                  />
                </div>

                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Enter Section</label>

                  <input
                    type="text"
                    className="input-pillar animate__animated animate__bounceIn"
                    ref={sectionRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "row" }}>
                  <label style={{ textAlign: "left" }}>Enter Percentage</label>

                  <input
                    type="text"
                    className="input-pillar animate__animated animate__bounceIn"
                    ref={percentRef}
                    onClick={handleInputClick}
                  />
                </div>
                <div className="btn-outcome-program">
                  <button
                    className="btn-outcome animate__animated animate__pulse"
                    style={{ borderRadius: "25px" }}
                  >
                    Add
                  </button>
                </div>
              </form>
            </Paper>
          </Box>
        </div>
      )}
    </Box>
  );
}
