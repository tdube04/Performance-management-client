import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import swal from "sweetalert";
import axiosClient from "../../../authentication/axios-client";

const AddDivision = () => {
  const divisionRef = useRef();
  const descriptionRef = useRef();
  const sectionRef = useRef();
  const [message, setMessage] = useState(null);
  const [sectionNames, setSectionNames] = useState("");

  const onSubmit = (ev) => {
    ev.preventDefault();

    const divisionName = divisionRef.current.value;
    const description = descriptionRef.current.value;
    const sectionNamesArray = sectionNames.split(",");

    if (!divisionName || !description || !sectionNamesArray.length) {
      setMessage("Please fill in all required fields");
      return;
    }

    const payload = {
      divisionName: divisionRef.current.value,
      description: descriptionRef.current.value,
      sectionName: sectionNamesArray,
    };

    axiosClient
      .post("/division/save", payload)
      .then((res) => {
        console.log(res);
        swal({
          text: "Division Saved Successfully",
          icon: "success",
          button: "OK!",
        }).then(() => {
          window.location.replace("/admin/addDivision");
        });
        divisionRef.current.value = "";
        descriptionRef.current.value = "";
        sectionRef.current.value = "";
        setSectionNames("");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleInputClick = () => {
    setMessage("");
  };

  const handleSectionChange = (event) => {
    setSectionNames(event.target.value);
  };

  return (
    <div>
      <Paper
        variant="outlined"
        sx={{
          mt: 15,
          ml: 40,
          p: 2,
          backgroundColor: "#FFFFFF",
          boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.3)",
          borderTop: "7px solid #309366",
          position: "relative",
          elevation: 3,
        }}
      >
        <h1>Add Division</h1>
        <br />
        <form onSubmit={onSubmit}>
          <label>Enter Division</label>
          <br />
          <input
            type="text"
            className="input-pillar"
            style={{ width: "100%" }}
            ref={divisionRef}
            onClick={handleInputClick}
          />

          <br />
          <label>Enter Description</label>
          <br />
          <input
            type="text"
            className="input-pillar"
            style={{ width: "100%" }}
            ref={descriptionRef}
            onClick={handleInputClick}
          />

          <br />

          <label htmlFor="suggestion">Add sections</label>
          <br />
          <input
            className="input-pillar"
            style={{ width: "100%" }}
            type="text"
            ref={sectionRef}
            onChange={handleSectionChange}
          />
          {message && (
            <div className="alert">
              <p>{message}</p>
            </div>
          )}
          <div className="btn-addPillar">
            <button className="pillar-btn" style={{ borderRadius: "25px" }}>
              Add
            </button>
          </div>
        </form>
      </Paper>
    </div>
  );
};

export default AddDivision;
