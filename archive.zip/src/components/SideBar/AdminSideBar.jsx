import "./sidebar.scss";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import StoreIcon from "@mui/icons-material/Store";
import InsertChartIcon from "@mui/icons-material/InsertChart";
import SettingsApplicationsIcon from "@mui/icons-material/SettingsApplications";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import SettingsSystemDaydreamOutlinedIcon from "@mui/icons-material/SettingsSystemDaydreamOutlined";
import PsychologyOutlinedIcon from "@mui/icons-material/PsychologyOutlined";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
import AssignmentIcon from "@mui/icons-material/Assignment";
import ListIcon from "@mui/icons-material/List";
import CreditScoreIcon from "@mui/icons-material/CreditScore";
import { Link } from "react-router-dom";
import AddCardIcon from "@mui/icons-material/AddCard";
import { useContext } from "react";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import HourglassEmptyIcon from "@mui/icons-material/HourglassEmpty";
import AssessmentIcon from "@mui/icons-material/Assessment";
import CancelIcon from "@mui/icons-material/Cancel";
import PendingIcon from "@mui/icons-material/Pending";
import FormatListBulletedIcon from "@mui/icons-material/FormatListBulleted";

const AdminSideBar = () => {
  return (
    <div className="sidebar">
      <div className="top">
        <Link to="/admin/dashboard" style={{ textDecoration: "none" }}>
          {/* <span className="logo">ZIMRA</span> */}
          <img
            src="/images/zimra.png"
            alt="ZIMRA logo"
            style={{ width: "200px", height: "auto" }}
          />
        </Link>
      </div>
      <hr />
      <div className="center">
        <ul>
          <li>
            <span>ADMIN Dashboard</span>
          </li>
          {/* <p className="title1">APPRAISEE VIEW</p> */}
          <p className="title">National Pillars</p>
          <Link to="/admin/addPillars" style={{ textDecoration: "none" }}>
            <li>
              <CheckCircleOutlineIcon className="icon" />
              <span>Add Pillars</span>
            </li>
          </Link>
          <Link to="/admin/viewPillars" style={{ textDecoration: "none" }}>
            <li>
              <PersonOutlineIcon className="icon" />

              <span>View Pillars</span>
            </li>
          </Link>

          <Link
            to="/admin/currentYearPillars"
            style={{ textDecoration: "none" }}
          >
            <li>
              <HourglassEmptyIcon className="icon" />
              <span>Select Current Year Pillar(s)</span>
            </li>
          </Link>

          <p className="title">Outcomes</p>
          <Link to="/admin/addOutcomes" style={{ textDecoration: "none" }}>
            <li>
              <FormatListBulletedIcon className="icon" />
              <span>Add</span>
            </li>
          </Link>
          <Link
            to="/admin/addOutcomes-information"
            style={{ textDecoration: "none" }}
          >
            <li>
              <FormatListBulletedIcon className="icon" />
              <span>For Current Year Quarter</span>
            </li>
          </Link>

          <p className="title">Divisions</p>

          <Link to="/admin/addDivision" style={{ textDecoration: "none" }}>
            <li>
              <CheckCircleOutlineIcon className="icon" />
              <span>Add</span>
            </li>
          </Link>

          <Link to="/admin/viewDivisions" style={{ textDecoration: "none" }}>
            <li>
              <CancelIcon className="icon" />
              <span>View</span>
            </li>
          </Link>
          <p className="title">Performance Areas</p>

          {/* <Link to="" style={{ textDecoration: "none" }}>
            <li>
              <CheckCircleOutlineIcon className="icon" />
              <span>Add Perfomance</span>
            </li>
          </Link> */}

          <Link to="/admin/performanceAreas" style={{ textDecoration: "none" }}>
            <li>
              <CancelIcon className="icon" />
              <span>View Perfomance</span>
            </li>
          </Link>
        </ul>
      </div>
    </div>
  );
};

export default AdminSideBar;
